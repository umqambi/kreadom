<?php get_header(); ?>

<div class="main-content-wrapper">

<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post-header">
                <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Постоянная ссылка на <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
            </div><!--.post-header-->
            <div class="entry clear">
                <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
                <?php the_content(); ?>
                <?php edit_post_link(); ?>
                <?php wp_link_pages(); ?>
            </div><!--. entry-->
        </div><!-- .post-->
    <?php endwhile; /* перемотка назад или дальше, если все посты были извлечены  */ ?>
    <nav class="navigation index">
        <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
        <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
    </nav><!--.navigation-->
    <?php else : ?>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?> 