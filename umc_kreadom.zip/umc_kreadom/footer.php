    <footer class="footer-site">
        <div class="wrap">
            <div class="foot-txt">
                <div class="contact-footer"> 
                    <a href="tel:+74822633185" class="tel">+7 (4822) 63-31-85</a> 
                    <a href="https://bitrix24public.com/krepost-69.bitrix24.ru/form/113_zapolnite_formu/2aifcu/" class="button btn-zakaz" data-name="Заказать звонок" role="button">Заказать звонок</a>
                    <div class="icon-mail"><a href="mailto:kreadomtver@yandex.ru">kreadomtver@yandex.ru</a></div>
                    <div class="adress">г. Тверь, пр-т Чайковского 28/2а <br>Перед приездом звоните!</div>
                    <div class="map-link"> <a href="#" class="button-write">Смотреть на карте</a></div>
                </div>
                <div class="cols-text">
                    <p>© 2014-2020</p>
                    <p>Сайт носит исключительно информационный характер и не является публичной офертой, определяемой положениями ГК РФ. Для получения подробной информации о наличии, видах, характеристиках и стоимости домов обращайтесь в офис продаж.</p>
                    <p><span style="text-decoration: underline;">
                        <a href="#">Политика конфиденциальности</a></span>
                    </p>
                </div>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?> 
</body>
</html>