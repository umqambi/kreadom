<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js"></script>
	<![endif]-->
    <?php wp_head(); ?>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" />
</head>
<body>
    <header>
        <div class="hwrap">
            <div class="header-nav-line">
                <a href="/" class="logo-site"> 
                    <span class="name">Креадом</span> 
                    <span class="desc">Дома под ключ</span> 
                </a>
                <div class="nav-box">
                    <div class="contact-head">
                        <div class="adress">г. Тверь, проспект Чайковского 28/2а <br>Перед приездом звоните!</div>
                        <div class="timework">
                            <div class="icon-time">Без выходных: 9:00-20:00</div>
                            <div class="icon-mail"><a href="mailto:kreadomtver@yandex.ru">kreadomtver@yandex.ru</a></div>
                        </div>
                        <div class="tel"> 
                            <a href="tel:+74951284641">+7 (4822) 63-31-85</a>
                        </div>
                        <div class="order-head"> 
                            <a href="https://bitrix24public.com/krepost-69.bitrix24.ru/form/113_zapolnite_formu/2aifcu/" class="button btn-zakaz" data-name="Заказать звонок" role="button">Заказать звонок</a>
                        </div>
                    </div>
                </div>
                <nav class="top-menu">
                    <ul>
                        <li><a href="#">Главная</a></li>
                        <li><a href="#">Услуги</a></li>
                        <li><a href="#">Скидки и акции</a></li>
                        <li><a href="#">Отзывы</a></li>
                        <li><a href="#">Фотогалерея</a></li>
                        <li><a href="#">О компании</a></li>
                        <li><a href="#">Контакты</a></li>
                    </ul>
                </nav>
            </div>
            <div class="header-content-line">

                <div class="title-head-text">
                    <h1>Строительство домов <br>под ключ в Твери и Тверской области</h1>
                </div>
                <div class="desc-head-text">
                    ✔ Качественные дома под ключ от 600 000 руб.<br>
                    ✔ Проекты и цены на любой вкус и бюджет.<br> 
                    ✔ Комплексное возведение дома от фундамента до крыши.
                </div>
                <div class="button-head-text"> 
                    <a href="https://bitrix24public.com/krepost-69.bitrix24.ru/form/113_zapolnite_formu/2aifcu/" class="button-project">Скачать проекты</a> 
                    <a href="https://bitrix24public.com/krepost-69.bitrix24.ru/form/113_zapolnite_formu/2aifcu/" class="button-home" data-name="Заявка на расчет стоимости">Заказать дом</a>
                </div> 

            </div>

        </div>
    </header>